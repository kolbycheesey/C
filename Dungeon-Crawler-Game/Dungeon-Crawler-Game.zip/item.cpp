#include <string>

#ifndef ITEM_H
#define ITEM_H

struct item {
  std::string name;
  int damage;
  int health;
};

#endif